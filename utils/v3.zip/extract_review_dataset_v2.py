import os
import re
from pathlib import Path
import fitz  # PyMuPDF


def extract_text_from_pdf(pdf_path: Path) -> str:
    """
    从 PDF 文件中提取文本，保留页脚以供参考文献识别使用。
    """
    doc = fitz.open(pdf_path)
    all_text = []
    for page in doc:
        text = page.get_text()
        # 可选：清除页码
        text = re.sub(r"\n\s*\d{1,3}\s*\n", "\n", text)
        all_text.append(text.strip())
    return "\n".join(all_text)


def extract_review_section(text: str) -> tuple[str, str]:
    """
    提取文献综述部分内容（review）和去除 review 后的正文。
    假设综述以 "2 Literature Review" 等开头，结束于下一一级标题或 References。
    """
    pattern = re.compile(r"\n\s*(\d+(\.\d+)?\.?\s+Literature Review.*?)\n", re.IGNORECASE)
    match = pattern.search(text)
    if not match:
        return "", text  # 没有综述部分

    start = match.start()
    next_section = re.search(r"\n\s*\d+(\.\d+)*\.?\s+[A-Z][^\n]{3,80}\n", text[match.end():])
    end = match.end() + (next_section.start() if next_section else 0)
    review = text[match.end():end].strip()
    rest = (text[:start] + text[end:]).strip()
    return review, rest


def extract_review_structure(review_text: str) -> str:
    """
    提取文献综述中的标题结构，例如 2.1 Verb Semantics、.8 Summary 等。
    """
    structure_lines = []
    for line in review_text.splitlines():
        if re.match(r"^\s*(\d+(\.\d+)*|\.\d+)\s+[A-Z][\w\- ]+", line.strip()):
            structure_lines.append(line.strip())
    return "\n".join(structure_lines)


def extract_all_references(text: str) -> str:
    """
    提取全文中的参考文献部分，从 References 起到文末。
    """
    match = re.search(r"(?i)\n\s*References\s*\n", text)
    if not match:
        return ""
    refs_text = text[match.end():].strip()
    return refs_text


def extract_references_in_review(review_text: str) -> str:
    """
    从综述中提取引用的参考文献（APA格式中的作者+年份）
    """
    citations = set(re.findall(r"\(([^()]*?\d{4}[a-z]?)\)", review_text))
    return "\n".join(sorted(citations))


def save_txt(content: str, path: Path):
    """
    保存文本到指定路径
    """
    path.write_text(content.strip(), encoding='utf-8')


def process_pdf(pdf_path: Path, output_dir: Path):
    """
    针对单个 PDF 文件提取五个输出文本文件
    """
    print(f"[+] 正在处理: {pdf_path.name}")
    text = extract_text_from_pdf(pdf_path)

    # 提取综述和正文
    review_text, maintext_wo_review = extract_review_section(text)
    references_in_review = extract_references_in_review(review_text)
    review_structure = extract_review_structure(review_text)
    all_references = extract_all_references(text)

    # 文件名基础
    base_name = pdf_path.stem

    # 保存五个文件
    save_txt(review_text, output_dir / f"{base_name}.review.txt")
    save_txt(maintext_wo_review, output_dir / f"{base_name}.maintext_wo_review.txt")
    save_txt(references_in_review, output_dir / f"{base_name}.references_in_review.txt")
    save_txt(review_structure, output_dir / f"{base_name}.review_structure.txt")
    save_txt(all_references, output_dir / f"{base_name}.all_references.txt")

    print(f"[✓] 完成：{base_name} → 生成 5 个 txt 文件\n")


def batch_process(input_dir: Path, output_dir: Path):
    """
    批量处理 input_dir 中的所有 PDF 文件，输出结果到 output_dir
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    pdf_files = list(input_dir.glob("*.pdf"))
    if not pdf_files:
        print("[!] 未发现 PDF 文件")
        return

    for pdf_file in pdf_files:
        process_pdf(pdf_file, output_dir)


if __name__ == "__main__":
    #  直接在此处配置输入输出路径（无需命令行参数）
    input_dir = Path("../utils")         # 修改为你的 PDF 存放路径
    output_dir = Path("")  # 输出五个 txt 的目录

    batch_process(input_dir, output_dir)
