import os
import re
import fitz  # PyMuPDF
from pathlib import Path

def extract_text_from_pdf(pdf_path):
    """提取PDF中的全部文本"""
    doc = fitz.open(pdf_path)
    text = "\n".join([page.get_text() for page in doc])
    doc.close()
    return text

def extract_review_section(text):
    """
    提取文献综述部分、其结构、引用内容及主文部分
    返回：review_text, review_structure, references_in_review, maintext_wo_review
    """
    # 匹配 "Literature Review" 或 "Related Work" 标题作为综述起点
    pattern = r"(?:\n|^)(\d{0,2}\.?\s?(?:Literature Review|Related Work)[^\n]*)\n"
    matches = list(re.finditer(pattern, text, re.IGNORECASE))

    if not matches:
        return None, None, None, text  # 未找到文献综述部分

    start = matches[0].start()
    next_section = re.search(r"\n\d{1,2}\.\s+[A-Z][^\n]+\n", text[matches[0].end():])
    end = matches[0].end() + (next_section.start() if next_section else len(text))

    review_text = text[start:end].strip()
    review_structure = "\n".join(re.findall(
        r"^(?:\d+(?:\.\d+)*\.?\s+)?[A-Z][^\n]{3,100}$", review_text, re.MULTILINE))
    references_in_review = sorted(set(re.findall(r"\(([^()]+?,\s?\d{4}[a-z]?)\)", review_text)))

    # 删除review部分得到主文
    maintext_wo_review = text[:start].strip() + "\n\n" + text[end:].strip()

    return review_text, review_structure, references_in_review, maintext_wo_review

def extract_references_section(text):
    """
    提取全文References段（APA格式原文）
    """
    match = re.search(r"\nReferences\s*\n", text, re.IGNORECASE)
    if not match:
        return ""
    return text[match.end():].strip()

def save_txt(content, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write(content.strip() if isinstance(content, str) else "\n".join(content))

def process_single_pdf(pdf_path: Path, output_dir: Path):
    """
    针对单篇PDF执行五个文件的生成任务
    """
    base_name = pdf_path.stem
    text = extract_text_from_pdf(pdf_path)

    review_text, review_structure, references_in_review, maintext_wo_review = extract_review_section(text)
    full_references = extract_references_section(text)

    if not review_text:
        print(f"[警告] {pdf_path.name} 中未检测到文献综述部分，跳过")
        return

    output_dir.mkdir(parents=True, exist_ok=True)
    save_txt(review_text, output_dir / f"{base_name}.review.txt")
    save_txt(maintext_wo_review, output_dir / f"{base_name}.maintext_wo_review.txt")
    save_txt(references_in_review, output_dir / f"{base_name}.references_in_review.txt")
    save_txt(review_structure, output_dir / f"{base_name}.review_structure.txt")
    save_txt(full_references, output_dir / f"{base_name}.all_references.txt")

    print(f"[完成] {base_name} 提取完成 ✔")

def process_all_pdfs(pdf_folder: str, output_folder: str):
    """
    针对指定目录下所有PDF文件，生成每篇5个对应的txt文件
    """
    pdf_folder = Path(pdf_folder)
    output_folder = Path(output_folder)
    pdf_files = list(pdf_folder.glob("*.pdf"))

    if not pdf_files:
        print(" 未在目录中找到PDF文件")
        return

    for pdf in pdf_files:
        process_single_pdf(pdf, output_folder)

# === 示例使用方式 ===
if __name__ == "__main__":
    # 修改为你本地的实际路径
    process_all_pdfs(
        pdf_folder="../utils",              #  输入PDF目录
        output_folder=""         #  输出TXT文件目录
    )
